Hi there!
Here it comes, new StepMix entry by Lisek, Star Crossed by Desyre grabbed from newgrounds with CC license.
Graphics are by Moonchilde, taken from her Moonchilde-Stock dA account (do visit her, really great works).
The song is a typical gallop-ish chart with 3/4 metrum, great for learning the execution of 1/12th notes.
Just like my previous works, every chart is quality-checked by Chmurek, the StepMix3 winner (the creator of Rockhill).

[Beginner][1]
Nothing special.

[Light][2]
Some jumps, once again nothing too special.

[Standard][5]
In this level it starts to get really fun. Some 1/12ths start to appear and there are crossovers. The song starts to be really jumpy on this difficulty.

[Heavy][8]
In the beginning it is really easy, but after a while, 1/12ths start to appear in little streams. Then you can encounter them everywhere, even in crossovers. Even the slow part is pretty tricky. The final part is synced to the piano, which makes the steps really interesting.

