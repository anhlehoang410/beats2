Last updated: 2011-01-12

These are some sample songs by stepfile created Lisek. Lisek originally created as entries for StepMania's StepMix contests but has granted permission for redistribution with Beats (see "Permission.jpg"). All original .mp3/.ogg files were re-encoded with foobar2000 (v0.9.6.8) to ~65kbps, "Smallest file" setting (lame -S --noreplaygain -V 9 --vbr-new - %filename%) and all image files were re-compressed with Adobe Photoshop CS3 as .jpg images at quality setting 5.

The songs are being redistributed with the intention of allowing users to try out the various features of Beats gameplay. All files here belong to their respective owners and can only be distributed under the same license in which they were first obtained (most/all of which are permissive Creative Commons). See the notes for individual song for details. The original song downloads and more of Lisek's work can be found here: http://simfile.pl/stepmix.html

~Keripo
